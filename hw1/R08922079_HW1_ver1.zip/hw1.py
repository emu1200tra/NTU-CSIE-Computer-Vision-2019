import cv2
import numpy as np
import math
'''
Part 1
'''
image = cv2.imread('lena.bmp')
print('shape:', image.shape)

#a. upside-down
updown = image[::-1,:,:]
cv2.imwrite("upsideDown.jpg", updown)

#b. right-side-left 
rightLeft = image[:,::-1,:]
cv2.imwrite("rightSideLeft.jpg", rightLeft)

#c. diagonally mirrored
diagonal = image[::-1,::-1,:]
cv2.imwrite("diagonal.jpg", diagonal)

'''
Part 2
'''
#a. rotate
#use software to complete

#b. shrink
#use software to complete

#c. binarize 
index = np.where(image>=128)
image[index] = 255
index = np.where(image<128)
image[index] = 0
cv2.imwrite("binarized.jpg", image)
